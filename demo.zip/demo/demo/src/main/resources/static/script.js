function loadEmployees() {

    fetch("/employees")
        .then(response => response.json())
        .then(data => {

            let tbody = document.querySelector("tbody");

            tbody.innerHTML = "";

            data.forEach(emp => {

                tbody.innerHTML += `
                <tr>
                    <td>${emp.id}</td>
                    <td>${emp.name}</td>
                    <td>${emp.department}</td>
                </tr>
                `;
            });

        })
        .catch(error => {
            console.error(error);
            alert("Unable to fetch employees.");
        });
}