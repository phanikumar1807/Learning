package com.phani.demo.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.phani.demo.entity.Employee;
import com.phani.demo.repository.EmployeeRepository;

@Service
public class EmployeeService {

    private final EmployeeRepository repository;

    public EmployeeService(EmployeeRepository repository){
        this.repository = repository;
    }

    public List<Employee> getEmployees(){
        return repository.findAll();
    }

}