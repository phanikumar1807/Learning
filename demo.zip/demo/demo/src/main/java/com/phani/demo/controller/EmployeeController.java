package com.phani.demo.controller;

import java.util.List;

import org.springframework.web.bind.annotation.*;

import com.phani.demo.entity.Employee;
import com.phani.demo.service.EmployeeService;

@RestController
@RequestMapping("/employees")

@CrossOrigin(origins="*")

public class EmployeeController {

    private final EmployeeService service;

    public EmployeeController(EmployeeService service){
        this.service = service;
    }

    @GetMapping
    public List<Employee> getEmployees(){

        return service.getEmployees();

    }

}