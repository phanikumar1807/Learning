package com.phani.jira.dto;

public class UpdateReporterRequest {

    private String reporter;

    public String getReporter() {
        return reporter;
    }

    public void setReporter(String reporter) {
        this.reporter = reporter;
    }

}