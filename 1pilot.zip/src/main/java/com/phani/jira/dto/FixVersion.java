package com.phani.jira.dto;


public class FixVersion {

    private String name;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

}