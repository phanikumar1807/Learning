package com.phani.jira.dto;

public class IssueUpdateRequest {

    private String reporter;

    private String businessTestingCoordinator;

    public IssueUpdateRequest() {
    }

    public String getReporter() {
        return reporter;
    }

    public void setReporter(String reporter) {
        this.reporter = reporter;
    }

    public String getBusinessTestingCoordinator() {
        return businessTestingCoordinator;
    }

    public void setBusinessTestingCoordinator(String businessTestingCoordinator) {
        this.businessTestingCoordinator = businessTestingCoordinator;
    }

}