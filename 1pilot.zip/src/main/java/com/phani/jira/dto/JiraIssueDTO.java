package com.phani.jira.dto;


import java.util.ArrayList;
import java.util.List;


public class JiraIssueDTO {

    private String key;
    private String summary;
    private String fixVersion;
    private String issueType;
    private List<String> components = new ArrayList<>();
    private List<String> labels = new ArrayList<>();
    private String assignee;
    private String reporter;
    /**
     * Currently used by the frontend to display Jira Status.
     * (Will be renamed to 'status' in a future refactoring.)
     */
    private String location;
    private String businessTestingCoordinator;

    public JiraIssueDTO() {
    }

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public String getSummary() {
        return summary;
    }

    public void setSummary(String summary) {
        this.summary = summary;
    }

    public String getFixVersion() {
        return fixVersion;
    }

    public void setFixVersion(String fixVersion) {
        this.fixVersion = fixVersion;
    }

    public String getIssueType() {
        return issueType;
    }

    public void setIssueType(String issueType) {
        this.issueType = issueType;
    }

    public List<String> getComponents() {
        return components;
    }

    public void setComponents(List<String> components) {
        this.components = components;
    }

    public List<String> getLabels() {
        return labels;
    }

    public void setLabels(List<String> labels) {
        this.labels = labels;
    }

    public String getAssignee() {
        return assignee;
    }

    public void setAssignee(String assignee) {
        this.assignee = assignee;
    }

    public String getReporter() {
        return reporter;
    }

    public void setReporter(String reporter) {
        this.reporter = reporter;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getBusinessTestingCoordinator() {
        return businessTestingCoordinator;
    }

    public void setBusinessTestingCoordinator(String businessTestingCoordinator) {
        this.businessTestingCoordinator = businessTestingCoordinator;
    }

    @Override
    public String toString() {
        return "JiraIssueDTO{" +
                "key='" + key + '\'' +
                ", summary='" + summary + '\'' +
                ", fixVersion='" + fixVersion + '\'' +
                ", issueType='" + issueType + '\'' +
                ", components=" + components +
                ", labels=" + labels +
                ", assignee='" + assignee + '\'' +
                ", reporter='" + reporter + '\'' +
                ", location='" + location + '\'' +
                ", businessTestingCoordinator='" + businessTestingCoordinator + '\'' +
                '}';
    }
}