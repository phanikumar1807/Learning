package com.phani.jira.dto;

import java.util.ArrayList;
import java.util.List;

public class BulkUpdateRequest {

    private List<IssueUpdate> issues = new ArrayList<>();

    public List<IssueUpdate> getIssues() {
        return issues;
    }

    public void setIssues(List<IssueUpdate> issues) {
        this.issues = issues;
    }

    public static class IssueUpdate {

        private String issueKey;

        private String reporter;

        private String businessTestingCoordinator;

        public String getIssueKey() {
            return issueKey;
        }

        public void setIssueKey(String issueKey) {
            this.issueKey = issueKey;
        }

        public String getReporter() {
            return reporter;
        }

        public void setReporter(String reporter) {
            this.reporter = reporter;
        }

        public String getBusinessTestingCoordinator() {
            return businessTestingCoordinator;
        }

        public void setBusinessTestingCoordinator(String businessTestingCoordinator) {
            this.businessTestingCoordinator = businessTestingCoordinator;
        }
    }

}