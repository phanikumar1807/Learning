const searchButton = document.getElementById("searchButton");

searchButton.addEventListener("click", loadIssues);

async function loadIssues() {

    const jql = document.getElementById("jql").value.trim();

    if (!jql) {

        alert("Please enter a JQL query.");

        return;

    }

    const response = await fetch(
        "/api/issues?jql=" + encodeURIComponent(jql)
    );

    if (!response.ok) {

        alert("Unable to fetch issues.");

        return;

    }

    const issues = await response.json();

    const tbody =
        document.querySelector("#issuesTable tbody");

    tbody.innerHTML = "";

    issues.forEach(issue => {

        const row = document.createElement("tr");

        row.innerHTML = `
            <td>${issue.key ?? ""}</td>
            <td>${issue.fixVersion ?? ""}</td>
            <td>${issue.issueType ?? ""}</td>
            <td>${(issue.components || []).join(", ")}</td>
            <td>${(issue.labels || []).join(", ")}</td>
            <td>${issue.assignee ?? ""}</td>
            <td>${issue.reporter ?? ""}</td>
            <td>${issue.location ?? ""}</td>
            <td>${issue.businessTestingCoordinator ?? ""}</td>
        `;

        tbody.appendChild(row);

    });

}