// =======================================================
// Jira Dashboard - script.js (Starter for Part 4C)
// NOTE:
// This is the foundation for the editable dashboard.
// Integrate with the backend APIs created in Parts 3A-3C.
// =======================================================

let jiraBaseUrl = "";
let issues = [];
let filteredIssues = [];
let dirtyRows = new Map();
let currentPage = 1;
let pageSize = 10;

let sortColumn = "";
let ascending = true;

const jqlInput = document.getElementById("jql");
const searchButton = document.getElementById("searchButton");
const exportButton = document.getElementById("exportButton");
const saveAllButton = document.getElementById("saveAllButton");
const filterInput = document.getElementById("filterInput");
const pageSizeSelect = document.getElementById("pageSize");

const previousPage = document.getElementById("previousPage");
const nextPage = document.getElementById("nextPage");
const pageInfo = document.getElementById("pageInfo");

const issueCount = document.getElementById("issueCount");
const dirtyCounter = document.getElementById("dirtyCounter");
const spinner = document.getElementById("spinner");
const tableBody = document.querySelector("#issuesTable tbody");
const toast = document.getElementById("toast");

window.addEventListener("load", async () => {
    await loadConfig();

    searchButton.onclick = loadIssues;
    exportButton.onclick = exportExcel;
    saveAllButton.onclick = bulkSave;

    jqlInput.addEventListener("keydown", e => {
        if (e.key === "Enter") loadIssues();
    });

    filterInput.oninput = filterIssues;
});

async function loadConfig() {
    try {
        const r = await fetch("/api/config");
        if (!r.ok) return;
        const c = await r.json();
        jiraBaseUrl = c.jiraBaseUrl;
    } catch (e) {
        console.error(e);
    }
}

async function loadIssues() {
    const jql = jqlInput.value.trim();
    if (!jql) return;

    showSpinner(true);

    const r = await fetch("/api/issues?jql=" + encodeURIComponent(jql));

    issues = await r.json();
    filteredIssues = [...issues];
    dirtyRows.clear();
    renderTable();
    updateDirtyCounter();

    showSpinner(false);
}

function renderTable() {

    tableBody.innerHTML = "";

    filteredIssues.forEach(issue => {

        const tr = document.createElement("tr");

        tr.innerHTML = `
        <td>${issue.key}</td>
        <td>${issue.summary ?? ""}</td>
        <td>${issue.fixVersion ?? ""}</td>
        <td>${issue.issueType ?? ""}</td>
        <td>${(issue.components || []).join(", ")}</td>
        <td>${(issue.labels || []).join(", ")}</td>
        <td>${issue.assignee ?? ""}</td>

        <td>
            <input class="editable reporter"
                   value="${issue.reporter ?? ""}"
                   data-key="${issue.key}">
        </td>

        <td>${issue.location ?? ""}</td>

        <td>
            <input class="editable btc"
                   value="${issue.businessTestingCoordinator ?? ""}"
                   data-key="${issue.key}">
        </td>

        <td>
            <button class="save-button"
                    data-key="${issue.key}"
                    disabled>
                Save
            </button>
        </td>
        `;

        tableBody.appendChild(tr);
    });

    attachEvents();
}

function attachEvents() {

    document.querySelectorAll(".editable").forEach(i => {

        i.addEventListener("input", e => {

            const row = e.target.closest("tr");
            row.classList.add("dirty");

            const key = e.target.dataset.key;

            if (!dirtyRows.has(key)) {
                dirtyRows.set(key, {});
            }

            const obj = dirtyRows.get(key);

            if (e.target.classList.contains("reporter"))
                obj.reporter = e.target.value;

            if (e.target.classList.contains("btc"))
                obj.businessTestingCoordinator = e.target.value;

            row.querySelector(".save-button").disabled = false;

            updateDirtyCounter();

        });

    });

    document.querySelectorAll(".save-button").forEach(btn => {
        btn.onclick = () => saveRow(btn.dataset.key);
    });

}

async function saveRow(issueKey) {

    const data = dirtyRows.get(issueKey);
    if (!data) return;

    await fetch("/api/issues/" + issueKey, {
        method: "PUT",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify(data)
    });

    dirtyRows.delete(issueKey);
    updateDirtyCounter();
    showToast("Issue updated", "success");
}

async function bulkSave() {

    if (dirtyRows.size === 0) return;

    const payload = {
        issues: []
    };

    dirtyRows.forEach((v, k) => {
        payload.issues.push({
            issueKey: k,
            reporter: v.reporter,
            businessTestingCoordinator: v.businessTestingCoordinator
        });
    });

    await fetch("/api/issues/bulk", {
        method: "PUT",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify(payload)
    });

    dirtyRows.clear();
    updateDirtyCounter();
    showToast("Bulk update completed", "success");
}

function updateDirtyCounter() {
    dirtyCounter.innerText = "Unsaved Changes : " + dirtyRows.size;
    saveAllButton.disabled = dirtyRows.size === 0;
}

function filterIssues() {
}

function exportExcel() {
}

function showSpinner(show) {
    spinner.classList.toggle("hidden", !show);
}

function showToast(message, type) {
    toast.innerText = message;
    toast.className = "toast " + type;
    setTimeout(() => toast.className = "toast hidden", 3000);
}
