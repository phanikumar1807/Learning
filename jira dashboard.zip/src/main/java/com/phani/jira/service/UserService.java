package com.phani.jira.service;

import com.phani.jira.client.JiraClient;
import com.phani.jira.dto.JiraUserDTO;
import org.springframework.stereotype.Service;

import java.util.Collections;
import java.util.List;

@Service
public class UserService {

    private final JiraClient jiraClient;

    public UserService(JiraClient jiraClient) {
        this.jiraClient = jiraClient;
    }

    /**
     * Search Jira users.
     */
    public List<JiraUserDTO> searchUsers(String query) {

        if (query == null || query.trim().isEmpty()) {
            return Collections.emptyList();
        }

        return jiraClient.searchUsers(query.trim());

    }

}