package com.phani.jira.service;

import com.phani.jira.dto.JiraIssueDTO;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.stereotype.Service;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.List;

@Service
public class ExcelExportService {

    public byte[] export(List<JiraIssueDTO> issues) {

        try (Workbook workbook = new XSSFWorkbook();
             ByteArrayOutputStream outputStream = new ByteArrayOutputStream()) {

            Sheet sheet = workbook.createSheet("Jira Issues");

            CellStyle headerStyle = createHeaderStyle(workbook);

            String[] headers = {
                    "Key",
                    "Fix Version",
                    "Issue Type",
                    "Components",
                    "Labels",
                    "Assignee",
                    "Reporter",
                    "Location",
                    "Business Testing Coordinator"
            };

            // Header Row
            Row headerRow = sheet.createRow(0);

            for (int i = 0; i < headers.length; i++) {
                Cell cell = headerRow.createCell(i);
                cell.setCellValue(headers[i]);
                cell.setCellStyle(headerStyle);
            }

            // Data Rows
            int rowNum = 1;

            for (JiraIssueDTO issue : issues) {

                Row row = sheet.createRow(rowNum++);

                row.createCell(0).setCellValue(safe(issue.getKey()));
                row.createCell(1).setCellValue(safe(issue.getFixVersion()));
                row.createCell(2).setCellValue(safe(issue.getIssueType()));
                row.createCell(3).setCellValue(join(issue.getComponents()));
                row.createCell(4).setCellValue(join(issue.getLabels()));
                row.createCell(5).setCellValue(safe(issue.getAssignee()));
                row.createCell(6).setCellValue(safe(issue.getReporter()));
                row.createCell(7).setCellValue(safe(issue.getLocation()));
                row.createCell(8).setCellValue(safe(issue.getBusinessTestingCoordinator()));
            }

            // Auto-size columns
            for (int i = 0; i < headers.length; i++) {
                sheet.autoSizeColumn(i);
            }

            workbook.write(outputStream);

            return outputStream.toByteArray();

        } catch (IOException ex) {
            throw new RuntimeException("Failed to generate Excel file.", ex);
        }
    }

    private CellStyle createHeaderStyle(Workbook workbook) {

        Font font = workbook.createFont();
        font.setBold(true);

        CellStyle style = workbook.createCellStyle();
        style.setFont(font);
        style.setFillForegroundColor(IndexedColors.GREY_25_PERCENT.getIndex());
        style.setFillPattern(FillPatternType.SOLID_FOREGROUND);

        return style;
    }

    private String join(List<String> values) {

        if (values == null || values.isEmpty()) {
            return "";
        }

        return String.join(", ", values);
    }

    private String safe(String value) {
        return value == null ? "" : value;
    }

}