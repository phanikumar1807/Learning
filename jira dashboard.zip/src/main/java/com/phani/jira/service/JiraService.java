package com.phani.jira.service;

import com.phani.jira.client.JiraClient;
import com.phani.jira.dto.*;

import org.springframework.stereotype.Service;

import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class JiraService {

    private final JiraClient jiraClient;

    public JiraService(JiraClient jiraClient) {
        this.jiraClient = jiraClient;
    }

    public String getCurrentUser() {
        return jiraClient.getCurrentUser();
    }

    public List<JiraIssueDTO> searchIssues(String jql) {

        JiraSearchResponse response = jiraClient.searchIssues(jql);

        if (response == null || response.getIssues() == null) {
            return Collections.emptyList();
        }

        return response.getIssues()
                .stream()
                .map(this::mapIssue)
                .collect(Collectors.toList());

    }

    private JiraIssueDTO mapIssue(Issue issue) {

        JiraIssueDTO dto = new JiraIssueDTO();

        dto.setKey(issue.getKey());

        IssueFields fields = issue.getFields();

        if (fields == null) {
            return dto;
        }

        if (fields.getFixVersions() != null && !fields.getFixVersions().isEmpty()) {
            dto.setFixVersion(fields.getFixVersions().get(0).getName());
        }

        if (fields.getIssueType() != null) {
            dto.setIssueType(fields.getIssueType().getName());
        }

        dto.setLabels(fields.getLabels());

        if (fields.getComponents() != null) {
            dto.setComponents(
                    fields.getComponents()
                            .stream()
                            .map(Component::getName)
                            .toList()
            );
        }

        if (fields.getAssignee() != null) {
            dto.setAssignee(fields.getAssignee().getDisplayName());
        }

        if (fields.getReporter() != null) {
            dto.setReporter(fields.getReporter().getDisplayName());
        }

        if (fields.getStatus() != null) {
            dto.setLocation(fields.getStatus().getName());
        }

        if (fields.getBusinessTestingCoordinator() != null) {
            dto.setBusinessTestingCoordinator(
                    fields.getBusinessTestingCoordinator().getDisplayName()
            );
        }

        return dto;

    }

}