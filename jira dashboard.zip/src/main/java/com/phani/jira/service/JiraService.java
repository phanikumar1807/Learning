package com.phani.jira.service;

import com.phani.jira.client.JiraClient;
import com.phani.jira.dto.*;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

@Service
public class JiraService {

    private final JiraClient jiraClient;

    public JiraService(JiraClient jiraClient) {
        this.jiraClient = jiraClient;
    }

    /**
     * Returns currently authenticated Jira user.
     */
    public String getCurrentUser() {
        return jiraClient.getCurrentUser();
    }

    /**
     * Search Jira issues using JQL.
     */
    public List<JiraIssueDTO> searchIssues(String jql) {

        JiraSearchResponse response = jiraClient.searchIssues(jql);

        if (response == null || response.getIssues() == null) {
            return Collections.emptyList();
        }

        List<JiraIssueDTO> result = new ArrayList<>();

        for (Issue issue : response.getIssues()) {
            result.add(mapIssue(issue));
        }

        return result;
    }

    /**
     * Search Jira users.
     */
    public List<JiraUserDTO> searchUsers(String query) {

        if (query == null || query.isBlank()) {
            return Collections.emptyList();
        }

        return jiraClient.searchUsers(query);

    }

    /**
     * Update a single Jira issue.
     */
    public void updateIssue(String issueKey,
                            IssueUpdateRequest request) {

        IssueUpdatePayload payload = buildPayload(request);

        jiraClient.updateIssue(issueKey, payload);

    }

    /**
     * Bulk update Jira issues.
     */
    public void bulkUpdate(BulkUpdateRequest request) {

        if (request == null
                || request.getIssues() == null
                || request.getIssues().isEmpty()) {
            return;
        }

        List<String> issueKeys = new ArrayList<>();
        List<IssueUpdatePayload> payloads = new ArrayList<>();

        for (BulkUpdateRequest.IssueUpdate update : request.getIssues()) {

            issueKeys.add(update.getIssueKey());

            IssueUpdateRequest updateRequest = new IssueUpdateRequest();

            updateRequest.setReporter(update.getReporter());

            updateRequest.setBusinessTestingCoordinator(
                    update.getBusinessTestingCoordinator());

            payloads.add(buildPayload(updateRequest));

        }

        jiraClient.bulkUpdate(issueKeys, payloads);

    }

    /**
     * Builds Jira REST payload.
     */
    private IssueUpdatePayload buildPayload(
            IssueUpdateRequest request) {

        IssueUpdatePayload payload = new IssueUpdatePayload();

        IssueUpdatePayload.Fields fields =
                new IssueUpdatePayload.Fields();

        if (request.getReporter() != null
                && !request.getReporter().isBlank()) {

            fields.setReporter(
                    new IssueUpdatePayload.JiraAccount(
                            request.getReporter()
                    )
            );

        }

        if (request.getBusinessTestingCoordinator() != null
                && !request.getBusinessTestingCoordinator().isBlank()) {

            fields.setBusinessTestingCoordinator(
                    new IssueUpdatePayload.JiraAccount(
                            request.getBusinessTestingCoordinator()
                    )
            );

        }

        payload.setFields(fields);

        return payload;

    }

    /**
     * Maps Jira Issue to Dashboard DTO.
     */
    private JiraIssueDTO mapIssue(Issue issue) {

        JiraIssueDTO dto = new JiraIssueDTO();

        dto.setKey(issue.getKey());

        IssueFields fields = issue.getFields();

        if (fields == null) {
            return dto;
        }

        if (fields.getSummary() != null) {
            dto.setSummary(fields.getSummary());
        }

        if (fields.getFixVersions() != null
                && !fields.getFixVersions().isEmpty()) {

            dto.setFixVersion(
                    fields.getFixVersions()
                            .get(0)
                            .getName());

        }

        if (fields.getIssueType() != null) {
            dto.setIssueType(
                    fields.getIssueType().getName());
        }

        dto.setLabels(fields.getLabels());

        if (fields.getComponents() != null) {

            dto.setComponents(
                    fields.getComponents()
                            .stream()
                            .map(Component::getName)
                            .toList()
            );

        }

        if (fields.getAssignee() != null) {
            dto.setAssignee(
                    fields.getAssignee().getDisplayName());
        }

        if (fields.getReporter() != null) {
            dto.setReporter(
                    fields.getReporter().getDisplayName());
        }

        if (fields.getStatus() != null) {
            dto.setLocation(
                    fields.getStatus().getName());
        }

        if (fields.getBusinessTestingCoordinator() != null) {
            dto.setBusinessTestingCoordinator(
                    fields.getBusinessTestingCoordinator()
                            .getDisplayName());
        }

        return dto;

    }

}