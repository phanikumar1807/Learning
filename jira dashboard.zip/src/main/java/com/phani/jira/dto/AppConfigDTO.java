package com.phani.jira.dto;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class AppConfigDTO {

    private String jiraBaseUrl;

}