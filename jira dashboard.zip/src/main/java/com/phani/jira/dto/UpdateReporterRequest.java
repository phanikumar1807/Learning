package com.phani.jira.dto;

import lombok.Data;

@Data
public class UpdateReporterRequest {

    private String reporter;

}