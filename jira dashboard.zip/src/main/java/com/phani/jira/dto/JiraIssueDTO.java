package com.phani.jira.dto;

import java.util.List;

public class JiraIssueDTO {

    private String key;

    private String fixVersion;

    private String issueType;

    private List<String> labels;

    private List<String> components;

    private String assignee;

    private String reporter;

    private String location;

    private String businessTestingCoordinator;

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public String getFixVersion() {
        return fixVersion;
    }

    public void setFixVersion(String fixVersion) {
        this.fixVersion = fixVersion;
    }

    public String getIssueType() {
        return issueType;
    }

    public void setIssueType(String issueType) {
        this.issueType = issueType;
    }

    public List<String> getLabels() {
        return labels;
    }

    public void setLabels(List<String> labels) {
        this.labels = labels;
    }

    public List<String> getComponents() {
        return components;
    }

    public void setComponents(List<String> components) {
        this.components = components;
    }

    public String getAssignee() {
        return assignee;
    }

    public void setAssignee(String assignee) {
        this.assignee = assignee;
    }

    public String getReporter() {
        return reporter;
    }

    public void setReporter(String reporter) {
        this.reporter = reporter;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getBusinessTestingCoordinator() {
        return businessTestingCoordinator;
    }

    public void setBusinessTestingCoordinator(String businessTestingCoordinator) {
        this.businessTestingCoordinator = businessTestingCoordinator;
    }
}