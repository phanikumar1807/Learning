package com.phani.jira.dto;

import lombok.Getter;
import lombok.Setter;

import java.util.ArrayList;
import java.util.List;

@Setter
@Getter
public class JiraIssueDTO {

    private String key;

    private String summary;

    private String fixVersion;

    private String issueType;

    private List<String> components = new ArrayList<>();

    private List<String> labels = new ArrayList<>();

    private String assignee;

    private String reporter;

    /**
     * Currently used by the frontend to display Jira Status.
     * (Will be renamed to 'status' in a future refactoring.)
     */
    private String location;

    private String businessTestingCoordinator;

    public JiraIssueDTO() {
    }

    @Override
    public String toString() {
        return "JiraIssueDTO{" +
                "key='" + key + '\'' +
                ", summary='" + summary + '\'' +
                ", fixVersion='" + fixVersion + '\'' +
                ", issueType='" + issueType + '\'' +
                ", components=" + components +
                ", labels=" + labels +
                ", assignee='" + assignee + '\'' +
                ", reporter='" + reporter + '\'' +
                ", location='" + location + '\'' +
                ", businessTestingCoordinator='" + businessTestingCoordinator + '\'' +
                '}';
    }
}