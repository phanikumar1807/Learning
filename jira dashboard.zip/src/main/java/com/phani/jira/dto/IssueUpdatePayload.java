package com.phani.jira.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.phani.jira.constants.JiraFieldConstants;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class IssueUpdatePayload {

    private Fields fields = new Fields();

    public static class Fields {

        private JiraAccount reporter;

        @JsonProperty(JiraFieldConstants.BUSINESS_TESTING_COORDINATOR)
        private JiraAccount businessTestingCoordinator;

        public JiraAccount getReporter() {
            return reporter;
        }

        public void setReporter(JiraAccount reporter) {
            this.reporter = reporter;
        }

        public JiraAccount getBusinessTestingCoordinator() {
            return businessTestingCoordinator;
        }

        public void setBusinessTestingCoordinator(JiraAccount businessTestingCoordinator) {
            this.businessTestingCoordinator = businessTestingCoordinator;
        }
    }

    public static class JiraAccount {

        private String accountId;

        public JiraAccount() {
        }

        public JiraAccount(String accountId) {
            this.accountId = accountId;
        }

        public String getAccountId() {
            return accountId;
        }

        public void setAccountId(String accountId) {
            this.accountId = accountId;
        }
    }

}