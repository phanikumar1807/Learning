package com.phani.jira.dto;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class IssueUpdateRequest {

    private String reporter;

    private String businessTestingCoordinator;

    public IssueUpdateRequest() {
    }

}