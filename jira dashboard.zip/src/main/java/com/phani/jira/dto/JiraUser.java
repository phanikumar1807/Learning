package com.phani.jira.dto;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class JiraUser {

    private String displayName;

}