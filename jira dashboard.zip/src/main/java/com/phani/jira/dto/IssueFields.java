package com.phani.jira.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Setter
@Getter
@JsonIgnoreProperties(ignoreUnknown = true)
public class IssueFields {

    private String summary;

    private List<FixVersion> fixVersions;

    @JsonProperty("issuetype")
    private IssueType issueType;

    private List<Component> components;

    private List<String> labels;

    private JiraUser assignee;

    private JiraUser reporter;

    private Status status;

    @JsonProperty("customfield_12701")
    private JiraUser businessTestingCoordinator;

}