package com.phani.jira.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.List;

@JsonIgnoreProperties(ignoreUnknown = true)
public class IssueFields {

    private List<FixVersion> fixVersions;

    @JsonProperty("issuetype")
    private IssueType issueType;

    private List<Component> components;

    private List<String> labels;

    private JiraUser assignee;

    private JiraUser reporter;

    private Status status;

    @JsonProperty("customfield_12701")
    private JiraUser businessTestingCoordinator;

    public List<FixVersion> getFixVersions() {
        return fixVersions;
    }

    public void setFixVersions(List<FixVersion> fixVersions) {
        this.fixVersions = fixVersions;
    }

    public IssueType getIssueType() {
        return issueType;
    }

    public void setIssueType(IssueType issueType) {
        this.issueType = issueType;
    }

    public List<Component> getComponents() {
        return components;
    }

    public void setComponents(List<Component> components) {
        this.components = components;
    }

    public List<String> getLabels() {
        return labels;
    }

    public void setLabels(List<String> labels) {
        this.labels = labels;
    }

    public JiraUser getAssignee() {
        return assignee;
    }

    public void setAssignee(JiraUser assignee) {
        this.assignee = assignee;
    }

    public JiraUser getReporter() {
        return reporter;
    }

    public void setReporter(JiraUser reporter) {
        this.reporter = reporter;
    }

    public Status getStatus() {
        return status;
    }

    public void setStatus(Status status) {
        this.status = status;
    }

    public JiraUser getBusinessTestingCoordinator() {
        return businessTestingCoordinator;
    }

    public void setBusinessTestingCoordinator(JiraUser businessTestingCoordinator) {
        this.businessTestingCoordinator = businessTestingCoordinator;
    }
}