package com.phani.jira.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@JsonIgnoreProperties(ignoreUnknown = true)
public class JiraUserDTO {

    private String accountId;

    private String displayName;

    private String emailAddress;

    private boolean active;

    public JiraUserDTO() {
    }

}