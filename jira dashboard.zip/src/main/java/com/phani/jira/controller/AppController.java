package com.phani.jira.controller;

import com.phani.jira.dto.AppConfigDTO;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class AppController {

    @Value("${jira.base-url}")
    private String jiraBaseUrl;

    @GetMapping("/api/config")
    public AppConfigDTO getConfiguration() {

        return new AppConfigDTO(jiraBaseUrl);

    }

}