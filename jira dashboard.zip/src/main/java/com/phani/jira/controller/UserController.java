package com.phani.jira.controller;

import com.phani.jira.dto.JiraUserDTO;
import com.phani.jira.service.UserService;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api/users")
public class UserController {

    private final UserService userService;

    public UserController(UserService userService) {
        this.userService = userService;
    }

    /**
     * Search Jira users for autocomplete.
     *
     * Example:
     * GET /api/users/search?query=phani
     */
    @GetMapping("/search")
    public List<JiraUserDTO> searchUsers(
            @RequestParam String query) {

        return userService.searchUsers(query);

    }

}