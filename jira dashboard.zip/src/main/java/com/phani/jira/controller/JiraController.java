package com.phani.jira.controller;

import com.phani.jira.dto.JiraIssueDTO;
import com.phani.jira.service.JiraService;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
public class JiraController {

    private final JiraService jiraService;

    public JiraController(JiraService jiraService) {
        this.jiraService = jiraService;
    }

    @GetMapping("/api/myself")
    public String myself() {
        return jiraService.getCurrentUser();
    }

    @GetMapping("/api/issues")
    public List<JiraIssueDTO> searchIssues(
            @RequestParam String jql) {

        return jiraService.searchIssues(jql);

    }

}