package com.phani.jira.controller;

import com.phani.jira.dto.BulkUpdateRequest;
import com.phani.jira.dto.IssueUpdateRequest;
import com.phani.jira.dto.JiraIssueDTO;
import com.phani.jira.service.JiraService;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api")
public class JiraController {

    private final JiraService jiraService;
    private final com.phani.jira.export.ExcelExportService excelExportService;

    public JiraController(
            JiraService jiraService,
            com.phani.jira.export.ExcelExportService excelExportService) {

        this.jiraService = jiraService;
        this.excelExportService = excelExportService;
    }

    /**
     * Returns current authenticated Jira user.
     */
    @GetMapping("/myself")
    public String getCurrentUser() {
        return jiraService.getCurrentUser();
    }

    /**
     * Search Jira Issues.
     */
    @GetMapping("/issues")
    public ResponseEntity<List<JiraIssueDTO>> searchIssues(
            @RequestParam String jql) {

        return ResponseEntity.ok(
                jiraService.searchIssues(jql)
        );
    }

    /**
     * Export Issues to Excel.
     */
    @GetMapping("/issues/export")
    public ResponseEntity<byte[]> exportIssues(
            @RequestParam String jql) {

        List<JiraIssueDTO> issues =
                jiraService.searchIssues(jql);

        byte[] excel =
                excelExportService.export(issues);

        return ResponseEntity.ok()
                .header(
                        HttpHeaders.CONTENT_DISPOSITION,
                        "attachment; filename=jira-issues.xlsx"
                )
                .contentLength(excel.length)
                .contentType(
                        MediaType.parseMediaType(
                                "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
                        )
                )
                .body(excel);

    }

    /**
     * Update one Jira Issue.
     */
    @PutMapping("/issues/{issueKey}")
    public ResponseEntity<Void> updateIssue(
            @PathVariable String issueKey,
            @RequestBody IssueUpdateRequest request) {

        jiraService.updateIssue(issueKey, request);

        return ResponseEntity.noContent().build();

    }

    /**
     * Bulk Update.
     */
    @PutMapping("/issues/bulk")
    public ResponseEntity<Void> bulkUpdate(
            @RequestBody BulkUpdateRequest request) {

        jiraService.bulkUpdate(request);

        return ResponseEntity.noContent().build();

    }

    /**
     * Health Check.
     */
    @GetMapping("/health")
    public ResponseEntity<String> health() {

        return ResponseEntity.ok("UP");

    }

    /**
     * Generic Exception Handler.
     */
    @ExceptionHandler(Exception.class)
    public ResponseEntity<String> handleException(
            Exception ex) {

        return ResponseEntity
                .status(HttpStatus.INTERNAL_SERVER_ERROR)
                .body(ex.getMessage());

    }

}