package com.phani.jira.constants;

public final class JiraFieldConstants {

    private JiraFieldConstants() {
    }

    /**
     * Jira Custom Field IDs
     * Change only these values if Jira custom field IDs change.
     */
    public static final String BUSINESS_TESTING_COORDINATOR = "customfield_12701";

    /**
     * REST API Paths
     */
    public static final String ISSUE_API = "/rest/api/2/issue";
    public static final String SEARCH_API = "/rest/api/2/search";
    public static final String USER_SEARCH_API = "/rest/api/2/user/search";
}