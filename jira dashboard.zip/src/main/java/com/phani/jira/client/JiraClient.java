package com.phani.jira.client;

import com.phani.jira.constants.JiraFieldConstants;
import com.phani.jira.dto.IssueUpdatePayload;
import com.phani.jira.dto.JiraSearchResponse;
import com.phani.jira.dto.JiraUserDTO;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestClient;

import java.util.List;

@Component
public class JiraClient {

    private final RestClient jiraRestClient;

    public JiraClient(RestClient jiraRestClient) {
        this.jiraRestClient = jiraRestClient;
    }

    /**
     * Verify Jira authentication.
     */
    public String getCurrentUser() {

        return jiraRestClient.get()
                .uri("/rest/api/2/myself")
                .retrieve()
                .body(String.class);

    }

    /**
     * Search Jira issues using JQL.
     */
    public JiraSearchResponse searchIssues(String jql) {

        return jiraRestClient.get()
                .uri(uriBuilder -> uriBuilder
                        .path(JiraFieldConstants.SEARCH_API)
                        .queryParam("jql", jql)
                        .queryParam(
                                "fields",
                                "summary,fixVersions,issuetype,components,labels,assignee,reporter,status,"
                                        + JiraFieldConstants.BUSINESS_TESTING_COORDINATOR
                        )
                        .build())
                .retrieve()
                .body(JiraSearchResponse.class);

    }

    /**
     * Search Jira users.
     */
    public List<JiraUserDTO> searchUsers(String query) {

        return jiraRestClient.get()
                .uri(uriBuilder -> uriBuilder
                        .path(JiraFieldConstants.USER_SEARCH_API)
                        .queryParam("query", query)
                        .build())
                .retrieve()
                .body(new ParameterizedTypeReference<List<JiraUserDTO>>() {
                });

    }

    /**
     * Update a single Jira issue.
     */
    public void updateIssue(String issueKey,
                            IssueUpdatePayload payload) {

        jiraRestClient.put()
                .uri(JiraFieldConstants.ISSUE_API + "/{issueKey}", issueKey)
                .body(payload)
                .retrieve()
                .toBodilessEntity();

    }

    /**
     * Bulk update helper.
     * Jira Server doesn't provide a true bulk update endpoint for these field
     * updates, so we simply iterate through the requests.
     */
    public void bulkUpdate(List<String> issueKeys,
                           List<IssueUpdatePayload> payloads) {

        if (issueKeys.size() != payloads.size()) {
            throw new IllegalArgumentException(
                    "Issue keys and payloads must have the same size.");
        }

        for (int i = 0; i < issueKeys.size(); i++) {
            updateIssue(issueKeys.get(i), payloads.get(i));
        }

    }

    /**
     * Simple health check.
     */
    public boolean ping() {

        try {

            ResponseEntity<Void> response =
                    jiraRestClient.get()
                            .uri("/rest/api/2/myself")
                            .retrieve()
                            .toBodilessEntity();

            return response.getStatusCode().is2xxSuccessful();

        } catch (Exception ex) {

            return false;

        }

    }

}