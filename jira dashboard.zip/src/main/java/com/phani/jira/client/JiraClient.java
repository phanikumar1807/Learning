package com.phani.jira.client;

import com.phani.jira.dto.JiraSearchResponse;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestClient;

@Component
public class JiraClient {

    private final RestClient jiraRestClient;

    public JiraClient(RestClient jiraRestClient) {
        this.jiraRestClient = jiraRestClient;
    }

    public String getCurrentUser() {

        return jiraRestClient.get()
                .uri("/rest/api/2/myself")
                .retrieve()
                .body(String.class);

    }

    public JiraSearchResponse searchIssues(String jql) {

        return jiraRestClient.get()
                .uri(uriBuilder -> uriBuilder
                        .path("/rest/api/2/search")
                        .queryParam("jql", jql)
                        .queryParam(
                                "fields",
                                "fixVersions,issuetype,components,labels,assignee,reporter,status,customfield_12701"
                        )
                        .build())
                .retrieve()
                .body(JiraSearchResponse.class);

    }

}